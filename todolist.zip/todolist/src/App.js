import './App.css';
import TodoList from './Components/todoList/TodoList';

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
